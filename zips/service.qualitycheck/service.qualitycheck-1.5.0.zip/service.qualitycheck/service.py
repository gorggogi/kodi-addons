import json

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

# The first notification shows as soon as the resolution is known.
STREAM_POLL_SECONDS = 0.1
STREAM_WAIT_SECONDS = 2.0
# After that, keep watching briefly in case the stream steps up or the bitrate appears.
FOLLOW_POLL_SECONDS = 0.5
FOLLOW_SECONDS = 6.0
TIERS = ('SD', '720p', '1080p', '4K')
# Matches the options of the Lowest resolution setting.
MIN_TIER_OPTIONS = ('720p', '1080p')

# These codecs look the same at a lower bitrate than H264.
EFFICIENT_CODECS = ('hevc', 'h265', 'hvc1', 'av1', 'vp9')
EFFICIENT_FACTOR = 0.6
# A smaller result means the size wasn't the video's, so the bitrate stays unknown.
MIN_BELIEVABLE_MBPS = 0.1

DEFAULTS = {
    'resolution_warning': True,
    'min_tier': '1080p',
    'bitrate_warning': True,
    'low_mbps': {'720p': 1.5, '1080p': 2.5, '4K': 8.0},
    'efficient_codecs': True,
    'always_show': False,
    'show_ms': 7000,
}


def load_settings():
    """Reads the settings each time, so changes apply to the next video."""
    try:
        addon = xbmcaddon.Addon()
        min_index = addon.getSettingInt('min_resolution')
        return {
            'resolution_warning': addon.getSettingBool('resolution_warning'),
            'min_tier': MIN_TIER_OPTIONS[min_index] if 0 <= min_index < len(MIN_TIER_OPTIONS) else '1080p',
            'bitrate_warning': addon.getSettingBool('bitrate_warning'),
            'low_mbps': {
                '720p': addon.getSettingNumber('mbps_720p'),
                '1080p': addon.getSettingNumber('mbps_1080p'),
                '4K': addon.getSettingNumber('mbps_4k'),
            },
            'efficient_codecs': addon.getSettingBool('efficient_codecs'),
            'always_show': addon.getSettingInt('show_mode') == 1,
            'show_ms': max(2, addon.getSettingInt('show_seconds')) * 1000,
        }
    except Exception as error:
        xbmc.log('[Quality Check] using default settings: %s' % error, xbmc.LOGWARNING)
        return dict(DEFAULTS, low_mbps=dict(DEFAULTS['low_mbps']))


def tier(width, height):
    # Width decides the tier, because widescreen movies have a reduced height.
    if width >= 3200 or height >= 1800:
        return '4K'
    if width >= 1800 or height >= 1000:
        return '1080p'
    if width >= 1200 or height >= 680:
        return '720p'
    return 'SD'


def is_good(quality, min_tier):
    return TIERS.index(quality) >= TIERS.index(min_tier)


def video_stream():
    request = {
        'jsonrpc': '2.0',
        'id': 1,
        'method': 'Player.GetProperties',
        'params': {'playerid': 1, 'properties': ['currentvideostream']},
    }
    try:
        reply = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
        stream = reply['result']['currentvideostream']
        width = int(stream.get('width') or 0)
        height = int(stream.get('height') or 0)
        return width, height, str(stream.get('codec') or '').lower()
    except Exception as error:
        xbmc.log('[Quality Check] could not read stream: %s' % error, xbmc.LOGWARNING)
        return 0, 0, ''


def reported_mbps():
    """Reads the bitrate Kodi reports, given in kilobits per second."""
    raw = xbmc.getInfoLabel('VideoPlayer.VideoBitrate')
    return int(raw) / 1000.0 if raw.isdigit() else 0.0


def file_mbps(player):
    """Works out the bitrate from file size and running time, audio included."""
    try:
        seconds = player.getTotalTime()
        video_file = xbmcvfs.File(player.getPlayingFile())
        try:
            size = video_file.size()
        finally:
            video_file.close()
    except Exception as error:
        xbmc.log('[Quality Check] could not read size: %s' % error, xbmc.LOGWARNING)
        return 0.0
    if seconds <= 0 or size <= 0:
        return 0.0
    mbps = size * 8 / seconds / 1000000.0
    return mbps if mbps >= MIN_BELIEVABLE_MBPS else 0.0


def low_limit(quality, codec, settings):
    """The bitrate warning level for this video, or 0 if it has none."""
    limit = settings['low_mbps'].get(quality) or 0.0
    if limit > 0 and settings['efficient_codecs'] and any(name in codec for name in EFFICIENT_CODECS):
        limit *= EFFICIENT_FACTOR
    return limit


class Watcher(xbmc.Player):
    def __init__(self, monitor):
        super().__init__()
        self.monitor = monitor
        self.settings = DEFAULTS

    def notify(self, heading, message, icon):
        xbmcgui.Dialog().notification(heading, message, icon, self.settings['show_ms'])
        xbmc.log('[Quality Check] %s %s' % (heading, message), xbmc.LOGINFO)

    def stopped(self, seconds):
        return self.monitor.waitForAbort(seconds) or not self.isPlayingVideo()

    def wait_for_stream(self):
        """Reads the resolution, retrying briefly if Kodi doesn't have it yet."""
        for _ in range(int(STREAM_WAIT_SECONDS / STREAM_POLL_SECONDS) + 1):
            width, height, codec = video_stream()
            if width:
                return width, height, codec
            if self.stopped(STREAM_POLL_SECONDS):
                break
        return 0, 0, ''

    def judge(self, width, height, codec, mbps):
        """Returns (kind, heading, message), where kind is low_res, low_bitrate or ok."""
        settings = self.settings
        quality = tier(width, height)
        if settings['resolution_warning'] and not is_good(quality, settings['min_tier']):
            message = '%dx%d' % (width, height)
            if settings['always_show'] and mbps:
                message += ', %.1f Mbps' % mbps
            return 'low_res', 'Low quality: ' + quality, message
        limit = low_limit(quality, codec, settings) if settings['bitrate_warning'] else 0.0
        if limit and mbps and mbps < limit:
            return 'low_bitrate', 'Low bitrate: %.1f Mbps' % mbps, '%dx%d, may look soft' % (width, height)
        rate = '%.1f Mbps' % mbps if mbps else 'bitrate unknown'
        return 'ok', '%s, %s' % (quality, rate), '%dx%d %s' % (width, height, codec.upper())

    def show(self, result, after_warning=False):
        kind, heading, message = result
        if kind != 'ok':
            self.notify(heading, message, xbmcgui.NOTIFICATION_WARNING)
        elif after_warning:
            # Clears up an earlier warning that turned out to be wrong.
            self.notify('Now ' + heading, message, xbmcgui.NOTIFICATION_INFO)
        elif self.settings['always_show']:
            self.notify(heading, message, xbmcgui.NOTIFICATION_INFO)
        else:
            xbmc.log('[Quality Check] OK %s %s' % (heading, message), xbmc.LOGINFO)

    def onAVStarted(self):
        if not self.isPlayingVideo():
            return
        self.settings = load_settings()
        settings = self.settings
        if not (settings['resolution_warning'] or settings['bitrate_warning'] or settings['always_show']):
            return
        width, height, codec = self.wait_for_stream()
        if not width or not self.isPlayingVideo():
            return
        mbps = reported_mbps() or file_mbps(self)
        first = self.judge(width, height, codec, mbps)
        self.show(first)
        self.follow_up(first, mbps)

    def follow_up(self, first, mbps):
        """Shows one more notification if the first one turns out wrong or incomplete."""
        waited = 0.0
        while waited < FOLLOW_SECONDS:
            if first[0] == 'ok' and mbps:
                return
            if self.stopped(FOLLOW_POLL_SECONDS):
                return
            waited += FOLLOW_POLL_SECONDS
            width, height, codec = video_stream()
            if not width:
                continue
            mbps = mbps or reported_mbps()
            latest = self.judge(width, height, codec, mbps)
            if latest[0] != first[0]:
                self.show(latest, after_warning=first[0] != 'ok')
                return
            if latest[0] == 'ok' and mbps:
                # The bitrate arrived late and is fine.
                if self.settings['always_show']:
                    self.show(latest)
                else:
                    xbmc.log('[Quality Check] OK %s %s' % (latest[1], latest[2]), xbmc.LOGINFO)
                return


if __name__ == '__main__':
    monitor = xbmc.Monitor()
    watcher = Watcher(monitor)
    monitor.waitForAbort()
