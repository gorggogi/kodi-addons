import json

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

CHECK_SECONDS = 1
MAX_CHECKS = 5
TIERS = ('SD', '720p', '1080p', '4K')
# Matches the options of the Lowest resolution setting.
MIN_TIER_OPTIONS = ('720p', '1080p')

# These codecs look the same at a lower bitrate than H264.
EFFICIENT_CODECS = ('hevc', 'h265', 'hvc1', 'av1', 'vp9')
EFFICIENT_FACTOR = 0.6
# A smaller result means the size wasn't the video's, so the bitrate stays unknown.
MIN_BELIEVABLE_MBPS = 0.1

DEFAULTS = {
    'resolution_warning': True,
    'min_tier': '1080p',
    'bitrate_warning': True,
    'low_mbps': {'720p': 1.5, '1080p': 2.5, '4K': 8.0},
    'efficient_codecs': True,
    'always_show': False,
    'show_ms': 7000,
}


def load_settings():
    """Reads the settings each time, so changes apply to the next video."""
    try:
        addon = xbmcaddon.Addon()
        min_index = addon.getSettingInt('min_resolution')
        return {
            'resolution_warning': addon.getSettingBool('resolution_warning'),
            'min_tier': MIN_TIER_OPTIONS[min_index] if 0 <= min_index < len(MIN_TIER_OPTIONS) else '1080p',
            'bitrate_warning': addon.getSettingBool('bitrate_warning'),
            'low_mbps': {
                '720p': addon.getSettingNumber('mbps_720p'),
                '1080p': addon.getSettingNumber('mbps_1080p'),
                '4K': addon.getSettingNumber('mbps_4k'),
            },
            'efficient_codecs': addon.getSettingBool('efficient_codecs'),
            'always_show': addon.getSettingInt('show_mode') == 1,
            'show_ms': max(2, addon.getSettingInt('show_seconds')) * 1000,
        }
    except Exception as error:
        xbmc.log('[Quality Check] using default settings: %s' % error, xbmc.LOGWARNING)
        return dict(DEFAULTS, low_mbps=dict(DEFAULTS['low_mbps']))


def tier(width, height):
    # Width decides the tier, because widescreen movies have a reduced height.
    if width >= 3200 or height >= 1800:
        return '4K'
    if width >= 1800 or height >= 1000:
        return '1080p'
    if width >= 1200 or height >= 680:
        return '720p'
    return 'SD'


def is_good(quality, min_tier):
    return TIERS.index(quality) >= TIERS.index(min_tier)


def video_stream():
    request = {
        'jsonrpc': '2.0',
        'id': 1,
        'method': 'Player.GetProperties',
        'params': {'playerid': 1, 'properties': ['currentvideostream']},
    }
    try:
        reply = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
        stream = reply['result']['currentvideostream']
        width = int(stream.get('width') or 0)
        height = int(stream.get('height') or 0)
        return width, height, str(stream.get('codec') or '').lower()
    except Exception as error:
        xbmc.log('[Quality Check] could not read stream: %s' % error, xbmc.LOGWARNING)
        return 0, 0, ''


def reported_mbps():
    """Reads the bitrate Kodi reports, given in kilobits per second."""
    raw = xbmc.getInfoLabel('VideoPlayer.VideoBitrate')
    return int(raw) / 1000.0 if raw.isdigit() else 0.0


def file_mbps(player):
    """Works out the bitrate from file size and running time, audio included."""
    try:
        seconds = player.getTotalTime()
        video_file = xbmcvfs.File(player.getPlayingFile())
        try:
            size = video_file.size()
        finally:
            video_file.close()
    except Exception as error:
        xbmc.log('[Quality Check] could not read size: %s' % error, xbmc.LOGWARNING)
        return 0.0
    if seconds <= 0 or size <= 0:
        return 0.0
    mbps = size * 8 / seconds / 1000000.0
    return mbps if mbps >= MIN_BELIEVABLE_MBPS else 0.0


def low_limit(quality, codec, settings):
    """The bitrate warning level for this video, or 0 if it has none."""
    limit = settings['low_mbps'].get(quality) or 0.0
    if limit > 0 and settings['efficient_codecs'] and any(name in codec for name in EFFICIENT_CODECS):
        limit *= EFFICIENT_FACTOR
    return limit


class Watcher(xbmc.Player):
    def __init__(self, monitor):
        super().__init__()
        self.monitor = monitor
        self.settings = DEFAULTS

    def notify(self, heading, message, icon):
        xbmcgui.Dialog().notification(heading, message, icon, self.settings['show_ms'])
        xbmc.log('[Quality Check] %s %s' % (heading, message), xbmc.LOGINFO)

    def warn(self, heading, message):
        self.notify(heading, message, xbmcgui.NOTIFICATION_WARNING)

    def read_mbps(self):
        # Kodi can take a moment to report the bitrate after playback starts.
        for _ in range(MAX_CHECKS):
            mbps = reported_mbps()
            if mbps:
                return mbps
            if self.monitor.waitForAbort(CHECK_SECONDS) or not self.isPlayingVideo():
                return 0.0
        return file_mbps(self)

    def check_bitrate(self, width, height, codec):
        quality = tier(width, height)
        limit = low_limit(quality, codec, self.settings) if self.settings['bitrate_warning'] else 0.0
        always = self.settings['always_show']
        if not limit and not always:
            xbmc.log('[Quality Check] OK %dx%d %s, bitrate not checked' % (width, height, codec), xbmc.LOGINFO)
            return
        mbps = self.read_mbps()
        if not self.isPlayingVideo():
            return
        if limit and mbps and mbps < limit:
            self.warn('Low bitrate: %.1f Mbps' % mbps, '%dx%d, may look soft' % (width, height))
            return
        rate = '%.1f Mbps' % mbps if mbps else 'bitrate unknown'
        if always:
            self.notify('%s, %s' % (quality, rate), '%dx%d %s' % (width, height, codec.upper()),
                        xbmcgui.NOTIFICATION_INFO)
        else:
            xbmc.log('[Quality Check] OK %dx%d %s %s' % (width, height, codec, rate), xbmc.LOGINFO)

    def warn_resolution(self, width, height):
        message = '%dx%d' % (width, height)
        if self.settings['always_show']:
            mbps = self.read_mbps()
            if not self.isPlayingVideo():
                return
            if mbps:
                message += ', %.1f Mbps' % mbps
        self.warn('Low quality: ' + tier(width, height), message)

    def onAVStarted(self):
        if not self.isPlayingVideo():
            return
        self.settings = load_settings()
        settings = self.settings
        if not (settings['resolution_warning'] or settings['bitrate_warning'] or settings['always_show']):
            return
        width = height = 0
        codec = ''
        # Streams can start low and step up, so only warn if it stays low.
        for _ in range(MAX_CHECKS):
            if self.monitor.waitForAbort(CHECK_SECONDS) or not self.isPlayingVideo():
                return
            read_width, read_height, read_codec = video_stream()
            if read_width:
                width, height, codec = read_width, read_height, read_codec
                if is_good(tier(width, height), settings['min_tier']):
                    self.check_bitrate(width, height, codec)
                    return
        if not width:
            return
        if settings['resolution_warning']:
            self.warn_resolution(width, height)
        else:
            self.check_bitrate(width, height, codec)


if __name__ == '__main__':
    monitor = xbmc.Monitor()
    watcher = Watcher(monitor)
    monitor.waitForAbort()
